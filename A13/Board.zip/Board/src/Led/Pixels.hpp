#pragma once

#include "Util/Util.hpp"
#include "port/port.hpp"

#include <set>
#include <vector>

namespace Board {
namespace Led {
class Pixels {
 public:
   static void init();
   static void set_brightness(float);
   static void set(int index, const Util::Color &color);
   static void set(const std::set<int> &indices, const Util::Color &color);
   static void set_sequence(int index, const std::vector<Util::Color> &sequence,
                            float sequence_index = 0);
   static void set_sequence(const std::set<int> &indices,
                            const std::vector<Util::Color> &sequence,
                            float sequence_index = 0);
   static void step_sequence(int index, float step_size);
   static void step_sequence(const std::set<int> &indices, float step_size);
   static void show();
   static void clear();
 private:
   static const int s_num_pixels = 4;
   static const int s_pin = 19;
   static const std::vector<Util::Color> s_default_sequence;

   static Adafruit_NeoPixel s_pixels;
   static std::vector<std::vector<Util::Color>> s_sequences;
   static float s_sequence_indices[s_num_pixels];
   static float s_brightness;
};
} // namespace Led
} // namespace Board