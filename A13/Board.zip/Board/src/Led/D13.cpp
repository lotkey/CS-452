#include "Led/D13.hpp"
#include "port/port.hpp"

namespace Board {
namespace Led {
bool D13::s_is_on = false;

void D13::init() {
   pinMode(s_led_pin, OUTPUT);
}

void D13::turn_on() {
   digitalWrite(s_led_pin, true);
   s_is_on = true;
}

void D13::turn_off() {
   digitalWrite(s_led_pin, false);
   s_is_on = false;
}

bool D13::invert() {
   s_is_on = !s_is_on;
   digitalWrite(s_led_pin, s_is_on);
   return s_is_on;
}

void D13::set(bool on) {
   s_is_on = on;
   digitalWrite(s_led_pin, s_is_on);
}

bool D13::is_on() { return s_is_on; }
} // namespace Board::Led
}