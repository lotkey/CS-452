#include "Led/Pixels.hpp"
#include "Util/Util.hpp"
#include "port/port.hpp"

#include <set>

namespace Board {
namespace Led {
Adafruit_NeoPixel Pixels::s_pixels =
    Adafruit_NeoPixel(s_num_pixels, s_pin, NEO_GRBW + NEO_KHZ800);
std::vector<std::vector<Util::Color>> Pixels::s_sequences;
float Pixels::s_sequence_indices[s_num_pixels];
float Pixels::s_brightness;
const std::vector<Util::Color> Pixels::s_default_sequence = {{0, 0, 0, 0}};

void Pixels::init() {
#if defined(__AVR_ATtiny85__) && (F_CPU == 16000000)
   clock_prescale_set(clock_div_1);
#endif
   for (int i = 0; i < s_num_pixels; i++) {
      s_sequences.push_back(s_default_sequence);
   }
   s_pixels.begin();
   s_pixels.clear();
}

void Pixels::set_brightness(float brightness) { s_brightness = brightness; }

void Pixels::set(int index, const Util::Color &color) {
   if (index < 0 || index >= s_num_pixels) {
      return;
   }

   s_pixels.setPixelColor(index,
                          s_pixels.Color(color.r(), color.g(), color.b()));
}

void Pixels::set(const std::set<int> &indices, const Util::Color &color) {
   for (const auto &index : indices) {
      set(index, color);
   }
}

void Pixels::set_sequence(int index, const std::vector<Util::Color> &sequence,
                          float sequence_index) {
   if (index < 0 || index >= s_num_pixels) {
      return;
   }

   s_sequences[index] = sequence;
   s_sequence_indices[index] = sequence_index;
}

void Pixels::set_sequence(const std::set<int> &indices,
                          const std::vector<Util::Color> &sequence,
                          float sequence_index) {
   for (const auto &index : indices) {
      set_sequence(index, sequence, sequence_index);
   }
}

void Pixels::step_sequence(int index, float step_size) {
   if (index < 0 || index >= s_num_pixels) {
      return;
   }

   s_sequence_indices[index] += step_size;
   while (s_sequence_indices[index] > s_sequences[index].size()) {
      s_sequence_indices[index] =
          s_sequences[index].size() - s_sequence_indices[index];
   }

   float c2_blend = s_sequence_indices[index] - (int)s_sequence_indices[index];
   float c1_blend = 1.0 - c2_blend;
   Util::Color c1 = s_sequences[index][(int)s_sequence_indices[index]];
   Util::Color c2 = s_sequences[index][((int)s_sequence_indices[index] + 1) %
                                       s_sequences[index].size()];
   Util::Color c3 = c1 * c1_blend + c2 * c2_blend;
   set(index, c3);
}

void Pixels::step_sequence(const std::set<int> &indices, float step_size) {
   for (const auto &index : indices) {
      step_sequence(index, step_size);
   }
}

void Pixels::show() { s_pixels.show(); }

void Pixels::clear() { s_pixels.clear(); }
} // namespace Led
} // namespace Board