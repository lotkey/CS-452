#pragma once

/// Namespace for controlling all LEDs on the board
namespace Board { 
namespace Led {}
}

#include "Led/D13.hpp"
#include "Led/Pixels.hpp"
#include "Led/Seven_segment.hpp"