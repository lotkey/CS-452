#pragma once

/// Namespace for controlling the board and its components
namespace Board {}

#include "Button.hpp"
#include "Dipswitch.hpp"
#include "Led/Led.hpp"
#include "Util/Util.hpp"