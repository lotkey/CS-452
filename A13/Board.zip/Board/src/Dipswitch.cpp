#include "Dipswitch.hpp"
#include "port/port.hpp"

#include <vector>

namespace Board {
const std::vector<uint> Dipswitch::s_pins = {6, 7, 3, 2, 13, 26, 0, 1};

void Dipswitch::init() {
   for (uint pin : s_pins) {
      pinMode(pin, INPUT);
   }
}

bool Dipswitch::get(uint switch_num) { return (bool)digitalRead(s_pins[switch_num]); }

std::vector<bool> Dipswitch::get() {
   std::vector<bool> status;
   for (uint pin : s_pins) {
      status.push_back((bool)digitalRead(s_pins[pin]));
   }
   return status;
}
} // namespace Board