#pragma once

typedef unsigned uint;

#include "port/map.hpp"
#include "port/optional.hpp"
#include "port/pair.hpp"
#include "port/set.hpp"
#include "port/tuple.hpp"

#include <Adafruit_NeoPixel.h>
#include <Arduino.h>
#ifdef __AVR__
#include <avr/power.h>
#endif