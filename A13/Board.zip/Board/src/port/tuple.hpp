#pragma once

#include <tuple>

namespace port
{
    template <typename T1, typename T2>
    void unpack(const std::tuple<T1, T2> &tuple, T1 &t1, T2 &t2)
    {
        t1 = std::get<0>(tuple);
        t2 = std::get<1>(tuple);
    }

    template <typename T1, typename T2, typename T3>
    void unpack(const std::tuple<T1, T2, T3> &tuple, T1 &t1, T2 &t2, T3& t3)
    {
        t1 = std::get<0>(tuple);
        t2 = std::get<1>(tuple);
        t3 = std::get<2>(tuple);
    }

    template <typename T1, typename T2, typename T3, typename T4>
    void unpack(const std::tuple<T1, T2, T3, T4> &tuple, T1 &t1, T2 &t2, T3& t3, T4& t4)
    {
        t1 = std::get<0>(tuple);
        t2 = std::get<1>(tuple);
        t3 = std::get<2>(tuple);
        t4 = std::get<3>(tuple);
    }
}