#pragma once

#include <set>

namespace port
{
    template <typename T>
    bool contains(const std::set<T> &set, T t)
    {
        return set.find(t) != set.end();
    }
}