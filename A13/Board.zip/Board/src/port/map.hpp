#pragma once

#include <map>

namespace port
{
    template <typename T1, typename T2>
    bool contains(const std::map<T1, T2> &map, T1 t)
    {
        return map.find(t) != map.end();
    }
}