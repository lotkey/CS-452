#pragma once

#include <tuple>

namespace port
{
    template <typename T1, typename T2>
    void unpack(const std::pair<T1, T2> &pair, T1 &t1, T2 &t2)
    {
        t1 = std::get<0>(pair);
        t2 = std::get<1>(pair);
    }
}