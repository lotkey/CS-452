#pragma once

namespace port
{
    template <typename T>
    class optional
    {
    public:
        optional() : m_has_value(false) {}

        optional(const T &value) : m_has_value(true), m_value(value) {}

        bool has_value() const
        {
            return m_has_value;
        }

        T &value()
        {
            return m_value;
        }

        void operator=(const T &t)
        {
            m_value = t;
            m_has_value = true;
        }

    private:
        bool m_has_value = false;
        T m_value;
    };
}