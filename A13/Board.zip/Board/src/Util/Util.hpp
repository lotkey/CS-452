#pragma once

/// Namespace for utilities used to control the board
/// Does not control the board
namespace Board {
namespace Util {}
}

#include "Util/Color.hpp"
#include "Util/colors.hpp"