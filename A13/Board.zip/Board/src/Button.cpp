#include "Button.hpp"
#include "port/port.hpp"

#include <vector>

namespace Board {
std::map<Button::Position, uint16_t> Button::s_state;

void Button::init() {
   pinMode((uint)Position::top_left, INPUT);
   pinMode((uint)Position::top_right, INPUT);
   pinMode((uint)Position::bottom, INPUT);
}

bool Button::get(Position pos) { return (bool)digitalRead((uint)pos); }

port::optional<Button::Position> Button::get() {
   std::vector<Position> positions = {Position::top_left, Position::top_right,
                                      Position::bottom};
   for (const auto &position : positions) {
      if (get(position)) {
         return position;
      }
   }
   return {};
}

bool Button::get_debounced(Position pos) {
   bool is_on = get(pos);
   s_state[pos] = (s_state[pos] << 1) | is_on | 0xfe00;

   return s_state[pos] == 0xff00;
}

port::optional<Button::Position> Button::get_debounced() {
   std::vector<Position> positions = {Position::top_left, Position::top_right,
                                      Position::bottom};
   for (const auto &position : positions) {
      if (get_debounced(position)) {
         return position;
      }
   }
   return {};
}
} // namespace Board