#pragma once

/// Namespace for utilities used to control the board
/// Does not control the board
namespace Board::Util {}

#include "Board/Util/Color.hpp"